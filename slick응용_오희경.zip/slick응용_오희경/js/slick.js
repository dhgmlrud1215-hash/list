$(function(){
    $('.slider').slick({
        dots: true,
        autoplay: true,
        infinite: true,
        autoplaySpeed: 2000,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $(".slick-button a").on("click",function(e){
        const n=$(this).index();
        if(n==0) {
            $(".slider").slick("slickUnfilter");
        }else if(n==1) {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter",$(".slider li").filter(".air"));
        }else if(n==2) {
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter",$(".slider li").filter(".humidifier"));
        }else{
            $(".slider").slick("slickUnfilter");
            $(".slider").slick("slickFilter",$(".slider li").filter(".moss"))
        }
        e.preventDefault();
    });
});